> install.packages("normtest")
Installing package into 'C:/Users/Alunos/Documents/R/win-library/3.5'
(as 'lib' is unspecified)
trying URL 'https://cran.rstudio.com/bin/windows/contrib/3.5/normtest_1.1.zip'
Content type 'application/zip' length 49535 bytes (48 KB)
downloaded 48 KB

package 'normtest' successfully unpacked and MD5 sums checked

The downloaded binary packages are in
C:\Users\Alunos\AppData\Local\Temp\RtmpaYFn9c\downloaded_packages
> install.packages("agricolae")
Installing package into 'C:/Users/Alunos/Documents/R/win-library/3.5'
(as 'lib' is unspecified)
also installing the dependencies 'bindr', 'purrr', 'forcats', 'bindrcpp', 'tidyselect', 'plogr', 'httpuv', 'mime', 'jsonlite', 'xtable', 'sourcetools', 'later', 'promises', 'e1071', 'haven', 'dplyr', 'gtools', 'shiny', 'miniUI', 'rstudioapi', 'highr', 'classInt', 'htmltools', 'labelled', 'gdata', 'combinat', 'questionr', 'sp', 'spData', 'LearnBayes', 'deldir', 'coda', 'gmodels', 'expm', 'klaR', 'spdep', 'AlgDesign'

trying URL 'https://cran.rstudio.com/bin/windows/contrib/3.5/bindr_0.1.1.zip'
Content type 'application/zip' length 17700 bytes (17 KB)
downloaded 17 KB

trying URL 'https://cran.rstudio.com/bin/windows/contrib/3.5/purrr_0.2.5.zip'
Content type 'application/zip' length 294601 bytes (287 KB)
downloaded 287 KB

trying URL 'https://cran.rstudio.com/bin/windows/contrib/3.5/forcats_0.3.0.zip'
Content type 'application/zip' length 209515 bytes (204 KB)
downloaded 204 KB

trying URL 'https://cran.rstudio.com/bin/windows/contrib/3.5/bindrcpp_0.2.2.zip'
Content type 'application/zip' length 621596 bytes (607 KB)
downloaded 607 KB

trying URL 'https://cran.rstudio.com/bin/windows/contrib/3.5/tidyselect_0.2.4.zip'
Content type 'application/zip' length 621259 bytes (606 KB)
downloaded 606 KB

trying URL 'https://cran.rstudio.com/bin/windows/contrib/3.5/plogr_0.2.0.zip'
Content type 'application/zip' length 18730 bytes (18 KB)
downloaded 18 KB

trying URL 'https://cran.rstudio.com/bin/windows/contrib/3.5/httpuv_1.4.5.zip'
Content type 'application/zip' length 1181900 bytes (1.1 MB)
downloaded 1.1 MB

trying URL 'https://cran.rstudio.com/bin/windows/contrib/3.5/mime_0.5.zip'
Content type 'application/zip' length 46959 bytes (45 KB)
downloaded 45 KB

trying URL 'https://cran.rstudio.com/bin/windows/contrib/3.5/jsonlite_1.5.zip'
Content type 'application/zip' length 1203182 bytes (1.1 MB)
downloaded 1.1 MB

trying URL 'https://cran.rstudio.com/bin/windows/contrib/3.5/xtable_1.8-3.zip'
Content type 'application/zip' length 756006 bytes (738 KB)
downloaded 738 KB

trying URL 'https://cran.rstudio.com/bin/windows/contrib/3.5/sourcetools_0.1.7.zip'
Content type 'application/zip' length 530513 bytes (518 KB)
downloaded 518 KB

trying URL 'https://cran.rstudio.com/bin/windows/contrib/3.5/later_0.7.4.zip'
Content type 'application/zip' length 606792 bytes (592 KB)
downloaded 592 KB

trying URL 'https://cran.rstudio.com/bin/windows/contrib/3.5/promises_1.0.1.zip'
Content type 'application/zip' length 686432 bytes (670 KB)
downloaded 670 KB

trying URL 'https://cran.rstudio.com/bin/windows/contrib/3.5/e1071_1.7-0.zip'
Content type 'application/zip' length 1015606 bytes (991 KB)
downloaded 991 KB

trying URL 'https://cran.rstudio.com/bin/windows/contrib/3.5/haven_1.1.2.zip'
Content type 'application/zip' length 990210 bytes (967 KB)
downloaded 967 KB

trying URL 'https://cran.rstudio.com/bin/windows/contrib/3.5/dplyr_0.7.6.zip'
Content type 'application/zip' length 3055838 bytes (2.9 MB)
downloaded 2.9 MB

trying URL 'https://cran.rstudio.com/bin/windows/contrib/3.5/gtools_3.8.1.zip'
Content type 'application/zip' length 325610 bytes (317 KB)
downloaded 317 KB

trying URL 'https://cran.rstudio.com/bin/windows/contrib/3.5/shiny_1.1.0.zip'
Content type 'application/zip' length 3637336 bytes (3.5 MB)
downloaded 3.5 MB

trying URL 'https://cran.rstudio.com/bin/windows/contrib/3.5/miniUI_0.1.1.1.zip'
Content type 'application/zip' length 36118 bytes (35 KB)
downloaded 35 KB

trying URL 'https://cran.rstudio.com/bin/windows/contrib/3.5/rstudioapi_0.7.zip'
Content type 'application/zip' length 147542 bytes (144 KB)
downloaded 144 KB

trying URL 'https://cran.rstudio.com/bin/windows/contrib/3.5/highr_0.7.zip'
Content type 'application/zip' length 48215 bytes (47 KB)
downloaded 47 KB

trying URL 'https://cran.rstudio.com/bin/windows/contrib/3.5/classInt_0.2-3.zip'
Content type 'application/zip' length 78183 bytes (76 KB)
downloaded 76 KB

trying URL 'https://cran.rstudio.com/bin/windows/contrib/3.5/htmltools_0.3.6.zip'
Content type 'application/zip' length 659902 bytes (644 KB)
downloaded 644 KB

trying URL 'https://cran.rstudio.com/bin/windows/contrib/3.5/labelled_1.1.0.zip'
Content type 'application/zip' length 113034 bytes (110 KB)
downloaded 110 KB

trying URL 'https://cran.rstudio.com/bin/windows/contrib/3.5/gdata_2.18.0.zip'
Content type 'application/zip' length 1260175 bytes (1.2 MB)
downloaded 1.2 MB

trying URL 'https://cran.rstudio.com/bin/windows/contrib/3.5/combinat_0.0-8.zip'
Content type 'application/zip' length 42494 bytes (41 KB)
downloaded 41 KB

trying URL 'https://cran.rstudio.com/bin/windows/contrib/3.5/questionr_0.6.3.zip'
Content type 'application/zip' length 1592150 bytes (1.5 MB)
downloaded 1.5 MB

trying URL 'https://cran.rstudio.com/bin/windows/contrib/3.5/sp_1.3-1.zip'
Content type 'application/zip' length 1869115 bytes (1.8 MB)
downloaded 1.8 MB

trying URL 'https://cran.rstudio.com/bin/windows/contrib/3.5/spData_0.2.9.3.zip'
Content type 'application/zip' length 3971111 bytes (3.8 MB)
downloaded 3.8 MB

trying URL 'https://cran.rstudio.com/bin/windows/contrib/3.5/LearnBayes_2.15.1.zip'
Content type 'application/zip' length 1025302 bytes (1001 KB)
downloaded 1001 KB

trying URL 'https://cran.rstudio.com/bin/windows/contrib/3.5/deldir_0.1-15.zip'
Content type 'application/zip' length 237915 bytes (232 KB)
downloaded 232 KB

trying URL 'https://cran.rstudio.com/bin/windows/contrib/3.5/coda_0.19-1.zip'
Content type 'application/zip' length 320266 bytes (312 KB)
downloaded 312 KB

trying URL 'https://cran.rstudio.com/bin/windows/contrib/3.5/gmodels_2.18.1.zip'
Content type 'application/zip' length 113527 bytes (110 KB)
downloaded 110 KB

trying URL 'https://cran.rstudio.com/bin/windows/contrib/3.5/expm_0.999-2.zip'
Content type 'application/zip' length 236926 bytes (231 KB)
downloaded 231 KB

trying URL 'https://cran.rstudio.com/bin/windows/contrib/3.5/klaR_0.6-14.zip'
Content type 'application/zip' length 563512 bytes (550 KB)
downloaded 550 KB

trying URL 'https://cran.rstudio.com/bin/windows/contrib/3.5/spdep_0.7-8.zip'
Content type 'application/zip' length 3166677 bytes (3.0 MB)
downloaded 3.0 MB

trying URL 'https://cran.rstudio.com/bin/windows/contrib/3.5/AlgDesign_1.1-7.3.zip'
Content type 'application/zip' length 620172 bytes (605 KB)
downloaded 605 KB

trying URL 'https://cran.rstudio.com/bin/windows/contrib/3.5/agricolae_1.2-8.zip'
Content type 'application/zip' length 1272842 bytes (1.2 MB)
downloaded 1.2 MB

package 'bindr' successfully unpacked and MD5 sums checked
package 'purrr' successfully unpacked and MD5 sums checked
package 'forcats' successfully unpacked and MD5 sums checked
package 'bindrcpp' successfully unpacked and MD5 sums checked
package 'tidyselect' successfully unpacked and MD5 sums checked
package 'plogr' successfully unpacked and MD5 sums checked
package 'httpuv' successfully unpacked and MD5 sums checked
package 'mime' successfully unpacked and MD5 sums checked
package 'jsonlite' successfully unpacked and MD5 sums checked
package 'xtable' successfully unpacked and MD5 sums checked
package 'sourcetools' successfully unpacked and MD5 sums checked
package 'later' successfully unpacked and MD5 sums checked
package 'promises' successfully unpacked and MD5 sums checked
package 'e1071' successfully unpacked and MD5 sums checked
package 'haven' successfully unpacked and MD5 sums checked
package 'dplyr' successfully unpacked and MD5 sums checked
package 'gtools' successfully unpacked and MD5 sums checked
package 'shiny' successfully unpacked and MD5 sums checked
package 'miniUI' successfully unpacked and MD5 sums checked
package 'rstudioapi' successfully unpacked and MD5 sums checked
package 'highr' successfully unpacked and MD5 sums checked
package 'classInt' successfully unpacked and MD5 sums checked
package 'htmltools' successfully unpacked and MD5 sums checked
package 'labelled' successfully unpacked and MD5 sums checked
package 'gdata' successfully unpacked and MD5 sums checked
package 'combinat' successfully unpacked and MD5 sums checked
package 'questionr' successfully unpacked and MD5 sums checked
package 'sp' successfully unpacked and MD5 sums checked
package 'spData' successfully unpacked and MD5 sums checked
package 'LearnBayes' successfully unpacked and MD5 sums checked
package 'deldir' successfully unpacked and MD5 sums checked
package 'coda' successfully unpacked and MD5 sums checked
package 'gmodels' successfully unpacked and MD5 sums checked
package 'expm' successfully unpacked and MD5 sums checked
package 'klaR' successfully unpacked and MD5 sums checked
package 'spdep' successfully unpacked and MD5 sums checked
package 'AlgDesign' successfully unpacked and MD5 sums checked
package 'agricolae' successfully unpacked and MD5 sums checked

The downloaded binary packages are in
C:\Users\Alunos\AppData\Local\Temp\RtmpaYFn9c\downloaded_packages
> library(agricolae)
> library(normtest)
> library(readxl)
> variacao_PIB <- read.table("c:/Econometria/variacao.xls", header = T)
> var_PIB <- ts(variacao_PIB$variacao_PIB, start =1951, frequency = 1 )
> AR2 <- arima(var_PIB,c(2,0,0))
> residuosAR2 <- AR2$residuals
> hist(residuosAR2)
> hist(residuosAR2, main = "Histograma dos Res�duos")
> hist(residuosAR2, main = "Histograma dos Res�duos", col="Gray")
> hist(residuosAR2, main = "Histograma dos Res�duos", col="Gray", breaks=20)
> hist(residuosAR2, main = "Histograma dos Residuos", col="Gray",breaks = 20,             
       +                xlab="Residuos",                                              #Altera o nome do eixo x para Residuos
       +                ylab = "Desnsidade",                                          #Altera o nome do eixo x para Densidade
       +                ylim = c(0,15),                                               #Altera a amplitude do eixo y: tamanho de 0 a 25
       +                xlim =c(-0.15,0.15)  )
> hist(residuosAR2, main = "Histograma dos Res�duos", col="Gray",breaks = 20,             
       +                xlab="Res�duos",                                              #Altera o nome do eixo x para Res�duos
       +                ylab = "Densidade",                                           #Altera o nome do eixo x para Densidade
       +                ylim = c(0,15),                                               #Altera a amplitude do eixo y: tamanho de 0 a 25
       +                xlim =c(-0.15,0.15)  )
> hist(residuosAR2, main = "Histograma dos Res�duos", col="Red",breaks = 20,             
       +                xlab="Res�duos",                                              #Altera o nome do eixo x para Res�duos
       +                ylab = "Densidade",                                           #Altera o nome do eixo x para Densidade
       +                ylim = c(0,15),                                               #Altera a amplitude do eixo y: tamanho de 0 a 25
       +                xlim =c(-0.15,0.15)  )
> hist(residuosAR2, main = "Histograma dos Res�duos", col="Brown",breaks = 20,             
       +                xlab="Res�duos",                                              #Altera o nome do eixo x para Res�duos
       +                ylab = "Densidade",                                           #Altera o nome do eixo x para Densidade
       +                ylim = c(0,15),                                               #Altera a amplitude do eixo y: tamanho de 0 a 25
       +                xlim =c(-0.15,0.15)  )
> hist(residuosAR2, main = "Histograma dos Res�duos", col="Purple",breaks = 20,             
       +                xlab="Res�duos",                                              #Altera o nome do eixo x para Res�duos
       +                ylab = "Densidade",                                           #Altera o nome do eixo x para Densidade
       +                ylim = c(0,15),                                               #Altera a amplitude do eixo y: tamanho de 0 a 25
       +                xlim =c(-0.15,0.15)  )
> hist(residuosAR2, main = "Histograma dos Res�duos", col="Violet",breaks = 20,             
       +                xlab="Res�duos",                                              #Altera o nome do eixo x para Res�duos
       +                ylab = "Densidade",                                           #Altera o nome do eixo x para Densidade
       +                ylim = c(0,15),                                               #Altera a amplitude do eixo y: tamanho de 0 a 25
       +                xlim =c(-0.15,0.15)  )
> lines(density(residuosAR2, bw=0.03),col="Blue")
> lines(density(residuosAR2, bw=0.03),col="Dark Green")
> lines(density(residuosAR2, bw=0.03),col="light blue")
> lines(density(residuosAR2, bw=0.03),col=blue")
        + lines(density(residuosAR2, bw=0.03),col='blue")
Error: unexpected string constant in:
  "lines(density(residuosAR2, bw=0.03),col=blue")
lines(density(residuosAR2, bw=0.03),col='blue""
      > lines(density(residuosAR2, bw=0.03),col="blue")
      > lines(density(residuosAR2, bw=0.03, kernel = "gaussian"),col="Blue")
      > lines(density(residuosAR2, bw=0.03, kernel = "triangular"),col="Red")
      > lines(density(residuosAR2, bw=0.03, kernel = "epanechnikov"),col="Yellow")
      > lines(density(residuosAR2, bw=0.03, kernel = "biweight"),col="Green")
      > hist(residuosAR2, main = "Histograma dos Res�duos", col="Gray",breaks = 20,             
      +      xlab="Res�duos",                                              
      +      ylab = "Densidade",                                          
      +      ylim = c(0,20),                                               
      +      xlim =c(-0.15,0.15)  )
      > lines(density(residuosAR2, bw=0.02),col="Blue")
      > lines(density(residuosAR2, bw=0.01),col="Red")
      > lines(density(residuosAR2, bw=0.005),col="Yellow")
      > jb.norm.test(residuosAR2)
      
      Jarque-Bera test for normality
      
      data:  residuosAR2
      JB = 6.6875, p-value = 0.036
      
      > skewness(residuosAR2)
      [1] -0.6093606
      > kurtosis(residuosAR2)
      [1] 1.305191