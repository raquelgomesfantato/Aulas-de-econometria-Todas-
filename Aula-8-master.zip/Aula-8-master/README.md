# Econometria Avançada - Aula 8 - Diagnóstico de resíduos (Parte 1)
* Arquivos e códigos feitos pelo professor;
* Resultados dos códigos;
* Slides da aula;
* Obs: Anotações feitas nos códigos; arquivos criados durante o processo serão subidos para cá.
