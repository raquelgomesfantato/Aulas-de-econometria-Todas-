# Aula-15
Econometria Avançada - Aula 15
