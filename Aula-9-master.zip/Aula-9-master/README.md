# Econometria Avançada - Aula 9 - Diagnóstico de resíduos (Parte 2)
* Arquivos e códigos feitos pelo professor;
* Resultados dos códigos;
* Slides da aula;
* Obs: Anotações feitas nos códigos; arquivos criados durante o processo serão subidos para cá.
