> install.packages("forecast")
Installing package into 'C:/Users/Alunos/Documents/R/win-library/3.5'
(as 'lib' is unspecified)
also installing the dependencies 'stringi', 'stringr', 'labeling', 'munsell', 'RColorBrewer', 'xts', 'TTR', 'curl', 'gtable', 'lazyeval', 'plyr', 'reshape2', 'scales', 'viridisLite', 'withr', 'quadprog', 'quantmod', 'colorspace', 'fracdiff', 'ggplot2', 'timeDate', 'tseries', 'urca', 'uroot', 'RcppArmadillo'


There is a binary version available but the source version is later:
  binary source needs_compilation
stringi  1.1.7  1.2.4              TRUE

Binaries will be installed
trying URL 'https://cran.rstudio.com/bin/windows/contrib/3.5/stringi_1.1.7.zip'
Content type 'application/zip' length 14368013 bytes (13.7 MB)
downloaded 13.7 MB

trying URL 'https://cran.rstudio.com/bin/windows/contrib/3.5/stringr_1.3.1.zip'
Content type 'application/zip' length 194427 bytes (189 KB)
downloaded 189 KB

trying URL 'https://cran.rstudio.com/bin/windows/contrib/3.5/labeling_0.3.zip'
Content type 'application/zip' length 61841 bytes (60 KB)
downloaded 60 KB

trying URL 'https://cran.rstudio.com/bin/windows/contrib/3.5/munsell_0.5.0.zip'
Content type 'application/zip' length 243606 bytes (237 KB)
downloaded 237 KB

trying URL 'https://cran.rstudio.com/bin/windows/contrib/3.5/RColorBrewer_1.1-2.zip'
Content type 'application/zip' length 55444 bytes (54 KB)
downloaded 54 KB

trying URL 'https://cran.rstudio.com/bin/windows/contrib/3.5/xts_0.11-1.zip'
Content type 'application/zip' length 953693 bytes (931 KB)
downloaded 931 KB

trying URL 'https://cran.rstudio.com/bin/windows/contrib/3.5/TTR_0.23-4.zip'
Content type 'application/zip' length 522959 bytes (510 KB)
downloaded 510 KB

trying URL 'https://cran.rstudio.com/bin/windows/contrib/3.5/curl_3.2.zip'
Content type 'application/zip' length 2986409 bytes (2.8 MB)
downloaded 2.8 MB

trying URL 'https://cran.rstudio.com/bin/windows/contrib/3.5/gtable_0.2.0.zip'
Content type 'application/zip' length 85220 bytes (83 KB)
downloaded 83 KB

trying URL 'https://cran.rstudio.com/bin/windows/contrib/3.5/lazyeval_0.2.1.zip'
Content type 'application/zip' length 167373 bytes (163 KB)
downloaded 163 KB

trying URL 'https://cran.rstudio.com/bin/windows/contrib/3.5/plyr_1.8.4.zip'
Content type 'application/zip' length 1297333 bytes (1.2 MB)
downloaded 1.2 MB

trying URL 'https://cran.rstudio.com/bin/windows/contrib/3.5/reshape2_1.4.3.zip'
Content type 'application/zip' length 625459 bytes (610 KB)
downloaded 610 KB

trying URL 'https://cran.rstudio.com/bin/windows/contrib/3.5/scales_1.0.0.zip'
Content type 'application/zip' length 1046657 bytes (1022 KB)
downloaded 1022 KB

trying URL 'https://cran.rstudio.com/bin/windows/contrib/3.5/viridisLite_0.3.0.zip'
Content type 'application/zip' length 60489 bytes (59 KB)
downloaded 59 KB

trying URL 'https://cran.rstudio.com/bin/windows/contrib/3.5/withr_2.1.2.zip'
Content type 'application/zip' length 150639 bytes (147 KB)
downloaded 147 KB

trying URL 'https://cran.rstudio.com/bin/windows/contrib/3.5/quadprog_1.5-5.zip'
Content type 'application/zip' length 301971 bytes (294 KB)
downloaded 294 KB

trying URL 'https://cran.rstudio.com/bin/windows/contrib/3.5/quantmod_0.4-13.zip'
Content type 'application/zip' length 942713 bytes (920 KB)
downloaded 920 KB

trying URL 'https://cran.rstudio.com/bin/windows/contrib/3.5/colorspace_1.3-2.zip'
Content type 'application/zip' length 527935 bytes (515 KB)
downloaded 515 KB

trying URL 'https://cran.rstudio.com/bin/windows/contrib/3.5/fracdiff_1.4-2.zip'
Content type 'application/zip' length 128578 bytes (125 KB)
downloaded 125 KB

trying URL 'https://cran.rstudio.com/bin/windows/contrib/3.5/ggplot2_3.0.0.zip'
Content type 'application/zip' length 3580057 bytes (3.4 MB)
downloaded 3.4 MB

trying URL 'https://cran.rstudio.com/bin/windows/contrib/3.5/timeDate_3043.102.zip'
Content type 'application/zip' length 1542922 bytes (1.5 MB)
downloaded 1.5 MB

trying URL 'https://cran.rstudio.com/bin/windows/contrib/3.5/tseries_0.10-45.zip'
Content type 'application/zip' length 414942 bytes (405 KB)
downloaded 405 KB

trying URL 'https://cran.rstudio.com/bin/windows/contrib/3.5/urca_1.3-0.zip'
Content type 'application/zip' length 1060448 bytes (1.0 MB)
downloaded 1.0 MB

trying URL 'https://cran.rstudio.com/bin/windows/contrib/3.5/uroot_2.0-9.zip'
Content type 'application/zip' length 1913338 bytes (1.8 MB)
downloaded 1.8 MB

trying URL 'https://cran.rstudio.com/bin/windows/contrib/3.5/RcppArmadillo_0.9.100.5.0.zip'
Content type 'application/zip' length 2268029 bytes (2.2 MB)
downloaded 2.2 MB

trying URL 'https://cran.rstudio.com/bin/windows/contrib/3.5/forecast_8.4.zip'
Content type 'application/zip' length 1996002 bytes (1.9 MB)
downloaded 1.9 MB

package 'stringi' successfully unpacked and MD5 sums checked
package 'stringr' successfully unpacked and MD5 sums checked
package 'labeling' successfully unpacked and MD5 sums checked
package 'munsell' successfully unpacked and MD5 sums checked
package 'RColorBrewer' successfully unpacked and MD5 sums checked
package 'xts' successfully unpacked and MD5 sums checked
package 'TTR' successfully unpacked and MD5 sums checked
package 'curl' successfully unpacked and MD5 sums checked
package 'gtable' successfully unpacked and MD5 sums checked
package 'lazyeval' successfully unpacked and MD5 sums checked
package 'plyr' successfully unpacked and MD5 sums checked
package 'reshape2' successfully unpacked and MD5 sums checked
package 'scales' successfully unpacked and MD5 sums checked
package 'viridisLite' successfully unpacked and MD5 sums checked
package 'withr' successfully unpacked and MD5 sums checked
package 'quadprog' successfully unpacked and MD5 sums checked
package 'quantmod' successfully unpacked and MD5 sums checked
package 'colorspace' successfully unpacked and MD5 sums checked
package 'fracdiff' successfully unpacked and MD5 sums checked
package 'ggplot2' successfully unpacked and MD5 sums checked
package 'timeDate' successfully unpacked and MD5 sums checked
package 'tseries' successfully unpacked and MD5 sums checked
package 'urca' successfully unpacked and MD5 sums checked
package 'uroot' successfully unpacked and MD5 sums checked
package 'RcppArmadillo' successfully unpacked and MD5 sums checked
package 'forecast' successfully unpacked and MD5 sums checked

The downloaded binary packages are in
C:\Users\Alunos\AppData\Local\Temp\RtmpgrDk90\downloaded_packages
> library(forecast)
> library(readxl)
> IPCA <- read_excel("C:/EconometriaA/IPCA.xls", col_types = c("date","numeric"))
> Inflacao <- ts(IPCA$IPCA,start = 2008, frequency = 12)
> View(Inflacao)
> Inflacao <- ts(IPCA$IPCA,start = 2008, frequency = 12)
> facp (Inflacao)
Error in facp(Inflacao) : could not find function "facp"
> FACP <- (Inflacao)
> pacf (Inflacao)
> acf (Inflacao)
> AR1 <- arima(Inflacao, order = c(1,0,0))
> AR1

Call:
  arima(x = Inflacao, order = c(1, 0, 0))

Coefficients:
  ar1  intercept
0.4648     0.4404
s.e.  0.0781     0.0513

sigma^2 estimated as 0.09696:  log likelihood = -32.15,  aic = 70.3
> AR2 <- arima(Inflacao, order = c(2,0,0))
> AR2

Call:
  arima(x = Inflacao, order = c(2, 0, 0))

Coefficients:
  ar1     ar2  intercept
0.4342  0.0636     0.4405
s.e.  0.0891  0.0899     0.0544

sigma^2 estimated as 0.09657:  log likelihood = -31.9,  aic = 71.8
> previsao1 <- forecast(AR1, 4)
> previsao1
Point Forecast       Lo 80     Hi 80      Lo 95     Hi 95
Aug 2018      0.3417960 -0.05725649 0.7408485 -0.2685021 0.9520942
Sep 2018      0.3945460 -0.04550140 0.8345934 -0.2784484 1.0675405
Oct 2018      0.4190628 -0.02934812 0.8674738 -0.2667225 1.1048482
Nov 2018      0.4304576 -0.01973958 0.8806548 -0.2580596 1.1189748
> previstoAR1 <- previsao1$fitted
> modelo1 <- data.frame(previstoAR1,Inflacao)
> modelo1 <- ts(modelo1,start = 2008-01, frequency = 12)
> plot(modelo1, main="Previsto e Observado - AR1", 
       +      plot.type="single",
       +      ylab="Data",
       +      xlab="Infla��o", 
       +      col=c("Blue","Black"))
> plot(modelo1, main="Previsto e Observado - AR1", 
       +      plot.type="single",
       +      ylab="Infla��o",
       +      xlab="Data", 
       +      col=c("Blue","Black"))
> previsao2 <- forecast(AR2, 4)
> previsao2
Point Forecast       Lo 80     Hi 80      Lo 95     Hi 95
Aug 2018      0.3846003 -0.01365917 0.7828597 -0.2244850 0.9936855
Sep 2018      0.4027537 -0.03142739 0.8369347 -0.2612690 1.0667763
Oct 2018      0.4205732 -0.02506585 0.8662122 -0.2609729 1.1021193
Nov 2018      0.4294645 -0.01950556 0.8784346 -0.2571760 1.1161051
> previstoAR2 <- previsao2$fitted
> modelo2 <- data.frame(previstoAR2,Inflacao)
> modelo2 <- ts(modelo2,start = 2008-01, frequency = 12)
> plot(modelo2, main="Previsto e Observado AR2", 
       +      plot.type="single",
       +      ylab="Infla��o", 
       +      xlab="Data", 
       +      col=c("Red","Black"))
> modeloconjunto <- data.frame(previstoAR1,previstoAR2,Inflacao)
> modeloconjunto <- ts(modeloconjunto,start = 2008-01, frequency = 12)
> modeloconjunto <- ts(modeloconjunto,start = 2008, frequency = 12)
> plot(modeloconjunto, main="Previsto e Observado AR1, AR2", 
       +      plot.type="single",
       +      ylab="Infla��o", 
       +      xlab="Data", 
       +      col=c("Blue", "Red","Black"))
> MA1 <- arima(Inflacao,order = c(0,0,1))
> MA1

Call:
  arima(x = Inflacao, order = c(0, 0, 1))

Coefficients:
  ma1  intercept
0.4415     0.4402
s.e.  0.0806     0.0405

sigma^2 estimated as 0.1007:  log likelihood = -34.52,  aic = 75.05
> MA2 <- arima(Inflacao,order = c(0,0,2))
> MA2

Call:
  arima(x = Inflacao, order = c(0, 0, 2))

Coefficients:
  ma1     ma2  intercept
0.4384  0.0925     0.4403
s.e.  0.0940  0.0889     0.0428

sigma^2 estimated as 0.09979:  log likelihood = -33.95,  aic = 75.91
> previsao01 <- forecast(MA1, 4)
> previsao01
Point Forecast        Lo 80     Hi 80      Lo 95     Hi 95
Aug 2018      0.2309465 -0.175670998 0.6375640 -0.3909213 0.8528143
Sep 2018      0.4402271 -0.004262149 0.8847164 -0.2395606 1.1200148
Oct 2018      0.4402271 -0.004262149 0.8847164 -0.2395606 1.1200148
Nov 2018      0.4402271 -0.004262149 0.8847164 -0.2395606 1.1200148
> previstoMA1 <- previsao01$fitted
> modelo01 <- data.frame(previstoMA1,Inflacao)
> modelo01 <- ts(modelo01,start = 2008-01, frequency = 12)
> modelo01 <- ts(modelo01,start = 2008, frequency = 12)
> plot(modelo01, main="Previsto e Observado - MA1", 
       +      plot.type="single",
       +      ylab="Infla��o", 
       +      xlab="Data", 
       +      col=c("Green","Black"))
> previsao02 <- forecast(MA2, 4)
> previsao02
Point Forecast        Lo 80     Hi 80      Lo 95     Hi 95
Aug 2018      0.2868967 -0.117941770 0.6917352 -0.3322503 0.9060438
Sep 2018      0.3954440 -0.046597736 0.8374858 -0.2806005 1.0714885
Oct 2018      0.4402753 -0.003349799 0.8839004 -0.2381907 1.1187413
Nov 2018      0.4402753 -0.003349799 0.8839004 -0.2381907 1.1187413
> previstoMA2 <- previsao02$fitted
> modelo02 <- data.frame(previstoMA2,Inflacao)
> modelo02 <- ts(modelo02,start = 2008, frequency = 12)
> plot(modelo02, main="Previsto e Observado AR2", plot.type="single",ylab="Infla��o", xlab="Data", col=c("Yellow","Black"))
> plot(modelo02, main="Previsto e Observado MA2", plot.type="single",ylab="Infla��o", xlab="Data", col=c("Yellow","Black"))
> modeloconjunto2 <- data.frame(previstoMA1,previstoMA2,Inflacao)
> modeloconjunto2 <- ts(modeloconjunto2,start = 2008, frequency = 12)
> plot(modeloconjunto2, main="Previsto e Observado AR1, AR2", plot.type="single",ylab="Infla��o", xlab="Data", col=c("Green", "Yellow","Black"))