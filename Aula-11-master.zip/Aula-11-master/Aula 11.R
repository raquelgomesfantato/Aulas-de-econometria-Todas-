> remove.packages(c("ggplot2", "data.table"))
Removing packages from 'C:/Users/lucas/Documents/R/win-library/3.5'
(as 'lib' is unspecified)
Error in remove.packages : there are no packages called 'ggplot2', 'data.table'
> install.packages('Rcpp', dependencies = TRUE)
Installing package into 'C:/Users/lucas/Documents/R/win-library/3.5'
(as 'lib' is unspecified)
also installing the dependencies 'glue', 'magrittr', 'stringi', 'digest', 'backports', 'xfun', 'evaluate', 'highr', 'markdown', 'stringr', 'yaml', 'htmltools', 'base64enc', 'jsonlite', 'rprojroot', 'mime', 'tinytex', 'RUnit', 'inline', 'rbenchmark', 'knitr', 'rmarkdown', 'pinp', 'pkgKitten'


There is a binary version available but the source version is later:
  binary source needs_compilation
stringi  1.1.7  1.2.4              TRUE

Binaries will be installed
trying URL 'https://cran.rstudio.com/bin/windows/contrib/3.5/glue_1.3.0.zip'
Content type 'application/zip' length 108457 bytes (105 KB)
downloaded 105 KB

trying URL 'https://cran.rstudio.com/bin/windows/contrib/3.5/magrittr_1.5.zip'
Content type 'application/zip' length 155760 bytes (152 KB)
downloaded 152 KB

trying URL 'https://cran.rstudio.com/bin/windows/contrib/3.5/stringi_1.1.7.zip'
Content type 'application/zip' length 14368013 bytes (13.7 MB)
downloaded 13.7 MB

trying URL 'https://cran.rstudio.com/bin/windows/contrib/3.5/digest_0.6.17.zip'
Content type 'application/zip' length 194312 bytes (189 KB)
downloaded 189 KB

trying URL 'https://cran.rstudio.com/bin/windows/contrib/3.5/backports_1.1.2.zip'
Content type 'application/zip' length 54833 bytes (53 KB)
downloaded 53 KB

trying URL 'https://cran.rstudio.com/bin/windows/contrib/3.5/xfun_0.3.zip'
Content type 'application/zip' length 149163 bytes (145 KB)
downloaded 145 KB

trying URL 'https://cran.rstudio.com/bin/windows/contrib/3.5/evaluate_0.11.zip'
Content type 'application/zip' length 73397 bytes (71 KB)
downloaded 71 KB

trying URL 'https://cran.rstudio.com/bin/windows/contrib/3.5/highr_0.7.zip'
Content type 'application/zip' length 48165 bytes (47 KB)
downloaded 47 KB

trying URL 'https://cran.rstudio.com/bin/windows/contrib/3.5/markdown_0.8.zip'
Content type 'application/zip' length 189500 bytes (185 KB)
downloaded 185 KB

trying URL 'https://cran.rstudio.com/bin/windows/contrib/3.5/stringr_1.3.1.zip'
Content type 'application/zip' length 194195 bytes (189 KB)
downloaded 189 KB

trying URL 'https://cran.rstudio.com/bin/windows/contrib/3.5/yaml_2.2.0.zip'
Content type 'application/zip' length 203553 bytes (198 KB)
downloaded 198 KB

trying URL 'https://cran.rstudio.com/bin/windows/contrib/3.5/htmltools_0.3.6.zip'
Content type 'application/zip' length 660733 bytes (645 KB)
downloaded 645 KB

trying URL 'https://cran.rstudio.com/bin/windows/contrib/3.5/base64enc_0.1-3.zip'
Content type 'application/zip' length 43294 bytes (42 KB)
downloaded 42 KB

trying URL 'https://cran.rstudio.com/bin/windows/contrib/3.5/jsonlite_1.5.zip'
Content type 'application/zip' length 1203081 bytes (1.1 MB)
downloaded 1.1 MB

trying URL 'https://cran.rstudio.com/bin/windows/contrib/3.5/rprojroot_1.3-2.zip'
Content type 'application/zip' length 83963 bytes (81 KB)
downloaded 81 KB

trying URL 'https://cran.rstudio.com/bin/windows/contrib/3.5/mime_0.6.zip'
Content type 'application/zip' length 47811 bytes (46 KB)
downloaded 46 KB

trying URL 'https://cran.rstudio.com/bin/windows/contrib/3.5/tinytex_0.8.zip'
Content type 'application/zip' length 87663 bytes (85 KB)
downloaded 85 KB

trying URL 'https://cran.rstudio.com/bin/windows/contrib/3.5/RUnit_0.4.32.zip'
Content type 'application/zip' length 296065 bytes (289 KB)
downloaded 289 KB

trying URL 'https://cran.rstudio.com/bin/windows/contrib/3.5/inline_0.3.15.zip'
Content type 'application/zip' length 123493 bytes (120 KB)
downloaded 120 KB

trying URL 'https://cran.rstudio.com/bin/windows/contrib/3.5/rbenchmark_1.0.0.zip'
Content type 'application/zip' length 22180 bytes (21 KB)
downloaded 21 KB

trying URL 'https://cran.rstudio.com/bin/windows/contrib/3.5/knitr_1.20.zip'
Content type 'application/zip' length 1182923 bytes (1.1 MB)
downloaded 1.1 MB

trying URL 'https://cran.rstudio.com/bin/windows/contrib/3.5/rmarkdown_1.10.zip'
Content type 'application/zip' length 2868896 bytes (2.7 MB)
downloaded 2.7 MB

trying URL 'https://cran.rstudio.com/bin/windows/contrib/3.5/pinp_0.0.6.zip'
Content type 'application/zip' length 217162 bytes (212 KB)
downloaded 212 KB

trying URL 'https://cran.rstudio.com/bin/windows/contrib/3.5/pkgKitten_0.1.4.zip'
Content type 'application/zip' length 23314 bytes (22 KB)
downloaded 22 KB

trying URL 'https://cran.rstudio.com/bin/windows/contrib/3.5/Rcpp_0.12.19.zip'
Content type 'application/zip' length 4565847 bytes (4.4 MB)
downloaded 4.4 MB

package 'glue' successfully unpacked and MD5 sums checked
package 'magrittr' successfully unpacked and MD5 sums checked
package 'stringi' successfully unpacked and MD5 sums checked
package 'digest' successfully unpacked and MD5 sums checked
package 'backports' successfully unpacked and MD5 sums checked
package 'xfun' successfully unpacked and MD5 sums checked
package 'evaluate' successfully unpacked and MD5 sums checked
package 'highr' successfully unpacked and MD5 sums checked
package 'markdown' successfully unpacked and MD5 sums checked
package 'stringr' successfully unpacked and MD5 sums checked
package 'yaml' successfully unpacked and MD5 sums checked
package 'htmltools' successfully unpacked and MD5 sums checked
package 'base64enc' successfully unpacked and MD5 sums checked
package 'jsonlite' successfully unpacked and MD5 sums checked
package 'rprojroot' successfully unpacked and MD5 sums checked
package 'mime' successfully unpacked and MD5 sums checked
package 'tinytex' successfully unpacked and MD5 sums checked
package 'RUnit' successfully unpacked and MD5 sums checked
package 'inline' successfully unpacked and MD5 sums checked
package 'rbenchmark' successfully unpacked and MD5 sums checked
package 'knitr' successfully unpacked and MD5 sums checked
package 'rmarkdown' successfully unpacked and MD5 sums checked
package 'pinp' successfully unpacked and MD5 sums checked
package 'pkgKitten' successfully unpacked and MD5 sums checked
package 'Rcpp' successfully unpacked and MD5 sums checked

The downloaded binary packages are in
C:\Users\lucas\AppData\Local\Temp\RtmpiWdPU6\downloaded_packages
> install.packages('ggplot2', dependencies = TRUE)
Installing package into 'C:/Users/lucas/Documents/R/win-library/3.5'
(as 'lib' is unspecified)
also installing the dependencies 'fansi', 'utf8', 'curl', 'openssl', 'bindr', 'checkmate', 'rstudioapi', 'zoo', 'memoise', 'whisker', 'git2r', 'fontBitstreamVera', 'fontLiberation', 'httpuv', 'xtable', 'sourcetools', 'later', 'promises', 'spData', 'e1071', 'labeling', 'R6', 'RColorBrewer', 'cli', 'crayon', 'pillar', 'rex', 'httr', 'assertthat', 'bindrcpp', 'pkgconfig', 'tidyselect', 'BH', 'plogr', 'Formula', 'latticeExtra', 'acepack', 'gridExtra', 'data.table', 'htmlTable', 'viridis', 'sp', 'mvtnorm', 'TH.data', 'sandwich', 'colorspace', 'praise', 'devtools', 'fontquiver', 'gdtools', 'htmlwidgets', 'purrr', 'shiny', 'xml2', 'SparseM', 'MatrixModels', 'DBI', 'units', 'classInt', 'gtable', 'lazyeval', 'plyr', 'reshape2', 'rlang', 'scales', 'tibble', 'viridisLite', 'withr', 'covr', 'dplyr', 'ggplot2movies', 'hexbin', 'Hmisc', 'mapproj', 'maps', 'maptools', 'multcomp', 'munsell', 'testthat', 'vdiffr', 'quantreg', 'rgeos', 'sf', 'svglite'

trying URL 'https://cran.rstudio.com/bin/windows/contrib/3.5/fansi_0.4.0.zip'
Content type 'application/zip' length 220335 bytes (215 KB)
downloaded 215 KB

trying URL 'https://cran.rstudio.com/bin/windows/contrib/3.5/utf8_1.1.4.zip'
Content type 'application/zip' length 214553 bytes (209 KB)
downloaded 209 KB

trying URL 'https://cran.rstudio.com/bin/windows/contrib/3.5/curl_3.2.zip'
Content type 'application/zip' length 2986361 bytes (2.8 MB)
downloaded 2.8 MB

trying URL 'https://cran.rstudio.com/bin/windows/contrib/3.5/openssl_1.0.2.zip'
Content type 'application/zip' length 3628621 bytes (3.5 MB)
downloaded 3.5 MB

trying URL 'https://cran.rstudio.com/bin/windows/contrib/3.5/bindr_0.1.1.zip'
Content type 'application/zip' length 17700 bytes (17 KB)
downloaded 17 KB

trying URL 'https://cran.rstudio.com/bin/windows/contrib/3.5/checkmate_1.8.5.zip'
Content type 'application/zip' length 630900 bytes (616 KB)
downloaded 616 KB

trying URL 'https://cran.rstudio.com/bin/windows/contrib/3.5/rstudioapi_0.8.zip'
Content type 'application/zip' length 177981 bytes (173 KB)
downloaded 173 KB

trying URL 'https://cran.rstudio.com/bin/windows/contrib/3.5/zoo_1.8-4.zip'
Content type 'application/zip' length 1098840 bytes (1.0 MB)
downloaded 1.0 MB

trying URL 'https://cran.rstudio.com/bin/windows/contrib/3.5/memoise_1.1.0.zip'
Content type 'application/zip' length 36437 bytes (35 KB)
downloaded 35 KB

trying URL 'https://cran.rstudio.com/bin/windows/contrib/3.5/whisker_0.3-2.zip'
Content type 'application/zip' length 81009 bytes (79 KB)
downloaded 79 KB

trying URL 'https://cran.rstudio.com/bin/windows/contrib/3.5/git2r_0.23.0.zip'
Content type 'application/zip' length 2872598 bytes (2.7 MB)
downloaded 2.7 MB

trying URL 'https://cran.rstudio.com/bin/windows/contrib/3.5/fontBitstreamVera_0.1.1.zip'
Content type 'application/zip' length 697547 bytes (681 KB)
downloaded 681 KB

trying URL 'https://cran.rstudio.com/bin/windows/contrib/3.5/fontLiberation_0.1.0.zip'
Content type 'application/zip' length 4530010 bytes (4.3 MB)
downloaded 4.3 MB

trying URL 'https://cran.rstudio.com/bin/windows/contrib/3.5/httpuv_1.4.5.zip'
Content type 'application/zip' length 1183550 bytes (1.1 MB)
downloaded 1.1 MB

trying URL 'https://cran.rstudio.com/bin/windows/contrib/3.5/xtable_1.8-3.zip'
Content type 'application/zip' length 755925 bytes (738 KB)
downloaded 738 KB

trying URL 'https://cran.rstudio.com/bin/windows/contrib/3.5/sourcetools_0.1.7.zip'
Content type 'application/zip' length 530515 bytes (518 KB)
downloaded 518 KB

trying URL 'https://cran.rstudio.com/bin/windows/contrib/3.5/later_0.7.5.zip'
Content type 'application/zip' length 617798 bytes (603 KB)
downloaded 603 KB

trying URL 'https://cran.rstudio.com/bin/windows/contrib/3.5/promises_1.0.1.zip'
Content type 'application/zip' length 692288 bytes (676 KB)
downloaded 676 KB

trying URL 'https://cran.rstudio.com/bin/windows/contrib/3.5/spData_0.2.9.4.zip'
Content type 'application/zip' length 3956526 bytes (3.8 MB)
downloaded 3.8 MB

trying URL 'https://cran.rstudio.com/bin/windows/contrib/3.5/e1071_1.7-0.zip'
Content type 'application/zip' length 1015365 bytes (991 KB)
downloaded 991 KB

trying URL 'https://cran.rstudio.com/bin/windows/contrib/3.5/labeling_0.3.zip'
Content type 'application/zip' length 61841 bytes (60 KB)
downloaded 60 KB

trying URL 'https://cran.rstudio.com/bin/windows/contrib/3.5/R6_2.3.0.zip'
Content type 'application/zip' length 57250 bytes (55 KB)
downloaded 55 KB

trying URL 'https://cran.rstudio.com/bin/windows/contrib/3.5/RColorBrewer_1.1-2.zip'
Content type 'application/zip' length 55444 bytes (54 KB)
downloaded 54 KB

trying URL 'https://cran.rstudio.com/bin/windows/contrib/3.5/cli_1.0.1.zip'
Content type 'application/zip' length 590029 bytes (576 KB)
downloaded 576 KB

trying URL 'https://cran.rstudio.com/bin/windows/contrib/3.5/crayon_1.3.4.zip'
Content type 'application/zip' length 748957 bytes (731 KB)
downloaded 731 KB

trying URL 'https://cran.rstudio.com/bin/windows/contrib/3.5/pillar_1.3.0.zip'
Content type 'application/zip' length 153180 bytes (149 KB)
downloaded 149 KB

trying URL 'https://cran.rstudio.com/bin/windows/contrib/3.5/rex_1.1.2.zip'
Content type 'application/zip' length 122549 bytes (119 KB)
downloaded 119 KB

trying URL 'https://cran.rstudio.com/bin/windows/contrib/3.5/httr_1.3.1.zip'
Content type 'application/zip' length 482200 bytes (470 KB)
downloaded 470 KB

trying URL 'https://cran.rstudio.com/bin/windows/contrib/3.5/assertthat_0.2.0.zip'
Content type 'application/zip' length 53749 bytes (52 KB)
downloaded 52 KB

trying URL 'https://cran.rstudio.com/bin/windows/contrib/3.5/bindrcpp_0.2.2.zip'
Content type 'application/zip' length 622852 bytes (608 KB)
downloaded 608 KB

trying URL 'https://cran.rstudio.com/bin/windows/contrib/3.5/pkgconfig_2.0.2.zip'
Content type 'application/zip' length 22144 bytes (21 KB)
downloaded 21 KB

trying URL 'https://cran.rstudio.com/bin/windows/contrib/3.5/tidyselect_0.2.4.zip'
Content type 'application/zip' length 622374 bytes (607 KB)
downloaded 607 KB

trying URL 'https://cran.rstudio.com/bin/windows/contrib/3.5/BH_1.66.0-1.zip'
Content type 'application/zip' length 17880019 bytes (17.1 MB)
downloaded 17.1 MB

trying URL 'https://cran.rstudio.com/bin/windows/contrib/3.5/plogr_0.2.0.zip'
Content type 'application/zip' length 18730 bytes (18 KB)
downloaded 18 KB

trying URL 'https://cran.rstudio.com/bin/windows/contrib/3.5/Formula_1.2-3.zip'
Content type 'application/zip' length 180903 bytes (176 KB)
downloaded 176 KB

trying URL 'https://cran.rstudio.com/bin/windows/contrib/3.5/latticeExtra_0.6-28.zip'
Content type 'application/zip' length 2192261 bytes (2.1 MB)
downloaded 2.1 MB

trying URL 'https://cran.rstudio.com/bin/windows/contrib/3.5/acepack_1.4.1.zip'
Content type 'application/zip' length 97947 bytes (95 KB)
downloaded 95 KB

trying URL 'https://cran.rstudio.com/bin/windows/contrib/3.5/gridExtra_2.3.zip'
Content type 'application/zip' length 1108753 bytes (1.1 MB)
downloaded 1.1 MB

trying URL 'https://cran.rstudio.com/bin/windows/contrib/3.5/data.table_1.11.8.zip'
Content type 'application/zip' length 1831980 bytes (1.7 MB)
downloaded 1.7 MB

trying URL 'https://cran.rstudio.com/bin/windows/contrib/3.5/htmlTable_1.12.zip'
Content type 'application/zip' length 322622 bytes (315 KB)
downloaded 315 KB

trying URL 'https://cran.rstudio.com/bin/windows/contrib/3.5/viridis_0.5.1.zip'
Content type 'application/zip' length 1866699 bytes (1.8 MB)
downloaded 1.8 MB

trying URL 'https://cran.rstudio.com/bin/windows/contrib/3.5/sp_1.3-1.zip'
Content type 'application/zip' length 1868711 bytes (1.8 MB)
downloaded 1.8 MB

trying URL 'https://cran.rstudio.com/bin/windows/contrib/3.5/mvtnorm_1.0-8.zip'
Content type 'application/zip' length 270167 bytes (263 KB)
downloaded 263 KB

trying URL 'https://cran.rstudio.com/bin/windows/contrib/3.5/TH.data_1.0-9.zip'
Content type 'application/zip' length 8464235 bytes (8.1 MB)
downloaded 8.1 MB

trying URL 'https://cran.rstudio.com/bin/windows/contrib/3.5/sandwich_2.5-0.zip'
Content type 'application/zip' length 1408505 bytes (1.3 MB)
downloaded 1.3 MB

trying URL 'https://cran.rstudio.com/bin/windows/contrib/3.5/colorspace_1.3-2.zip'
Content type 'application/zip' length 527915 bytes (515 KB)
downloaded 515 KB

trying URL 'https://cran.rstudio.com/bin/windows/contrib/3.5/praise_1.0.0.zip'
Content type 'application/zip' length 19483 bytes (19 KB)
downloaded 19 KB

trying URL 'https://cran.rstudio.com/bin/windows/contrib/3.5/devtools_1.13.6.zip'
Content type 'application/zip' length 701199 bytes (684 KB)
downloaded 684 KB

trying URL 'https://cran.rstudio.com/bin/windows/contrib/3.5/fontquiver_0.2.1.zip'
Content type 'application/zip' length 2277038 bytes (2.2 MB)
downloaded 2.2 MB

trying URL 'https://cran.rstudio.com/bin/windows/contrib/3.5/gdtools_0.1.7.zip'
Content type 'application/zip' length 3429458 bytes (3.3 MB)
downloaded 3.3 MB

trying URL 'https://cran.rstudio.com/bin/windows/contrib/3.5/htmlwidgets_1.3.zip'
Content type 'application/zip' length 804914 bytes (786 KB)
downloaded 786 KB

trying URL 'https://cran.rstudio.com/bin/windows/contrib/3.5/purrr_0.2.5.zip'
Content type 'application/zip' length 294499 bytes (287 KB)
downloaded 287 KB

trying URL 'https://cran.rstudio.com/bin/windows/contrib/3.5/shiny_1.1.0.zip'
Content type 'application/zip' length 3805687 bytes (3.6 MB)
downloaded 3.6 MB

trying URL 'https://cran.rstudio.com/bin/windows/contrib/3.5/xml2_1.2.0.zip'
Content type 'application/zip' length 3605645 bytes (3.4 MB)
downloaded 3.4 MB

trying URL 'https://cran.rstudio.com/bin/windows/contrib/3.5/SparseM_1.77.zip'
Content type 'application/zip' length 1374637 bytes (1.3 MB)
downloaded 1.3 MB

trying URL 'https://cran.rstudio.com/bin/windows/contrib/3.5/MatrixModels_0.4-1.zip'
Content type 'application/zip' length 381055 bytes (372 KB)
downloaded 372 KB

trying URL 'https://cran.rstudio.com/bin/windows/contrib/3.5/DBI_1.0.0.zip'
Content type 'application/zip' length 889354 bytes (868 KB)
downloaded 868 KB

trying URL 'https://cran.rstudio.com/bin/windows/contrib/3.5/units_0.6-1.zip'
Content type 'application/zip' length 1705083 bytes (1.6 MB)
downloaded 1.6 MB

trying URL 'https://cran.rstudio.com/bin/windows/contrib/3.5/classInt_0.2-3.zip'
Content type 'application/zip' length 78184 bytes (76 KB)
downloaded 76 KB

trying URL 'https://cran.rstudio.com/bin/windows/contrib/3.5/gtable_0.2.0.zip'
Content type 'application/zip' length 85267 bytes (83 KB)
downloaded 83 KB

trying URL 'https://cran.rstudio.com/bin/windows/contrib/3.5/lazyeval_0.2.1.zip'
Content type 'application/zip' length 167121 bytes (163 KB)
downloaded 163 KB

trying URL 'https://cran.rstudio.com/bin/windows/contrib/3.5/plyr_1.8.4.zip'
Content type 'application/zip' length 1297192 bytes (1.2 MB)
downloaded 1.2 MB

trying URL 'https://cran.rstudio.com/bin/windows/contrib/3.5/reshape2_1.4.3.zip'
Content type 'application/zip' length 625704 bytes (611 KB)
downloaded 611 KB

trying URL 'https://cran.rstudio.com/bin/windows/contrib/3.5/rlang_0.2.2.zip'
Content type 'application/zip' length 822056 bytes (802 KB)
downloaded 802 KB

trying URL 'https://cran.rstudio.com/bin/windows/contrib/3.5/scales_1.0.0.zip'
Content type 'application/zip' length 1063863 bytes (1.0 MB)
downloaded 1.0 MB

trying URL 'https://cran.rstudio.com/bin/windows/contrib/3.5/tibble_1.4.2.zip'
Content type 'application/zip' length 243791 bytes (238 KB)
downloaded 238 KB

trying URL 'https://cran.rstudio.com/bin/windows/contrib/3.5/viridisLite_0.3.0.zip'
Content type 'application/zip' length 60501 bytes (59 KB)
downloaded 59 KB

trying URL 'https://cran.rstudio.com/bin/windows/contrib/3.5/withr_2.1.2.zip'
Content type 'application/zip' length 150575 bytes (147 KB)
downloaded 147 KB

trying URL 'https://cran.rstudio.com/bin/windows/contrib/3.5/covr_3.2.0.zip'
Content type 'application/zip' length 288166 bytes (281 KB)
downloaded 281 KB

trying URL 'https://cran.rstudio.com/bin/windows/contrib/3.5/dplyr_0.7.6.zip'
Content type 'application/zip' length 3061551 bytes (2.9 MB)
downloaded 2.9 MB

trying URL 'https://cran.rstudio.com/bin/windows/contrib/3.5/ggplot2movies_0.0.1.zip'
Content type 'application/zip' length 1250501 bytes (1.2 MB)
downloaded 1.2 MB

trying URL 'https://cran.rstudio.com/bin/windows/contrib/3.5/hexbin_1.27.2.zip'
Content type 'application/zip' length 836529 bytes (816 KB)
downloaded 816 KB

trying URL 'https://cran.rstudio.com/bin/windows/contrib/3.5/Hmisc_4.1-1.zip'
Content type 'application/zip' length 3014451 bytes (2.9 MB)
downloaded 2.9 MB

trying URL 'https://cran.rstudio.com/bin/windows/contrib/3.5/mapproj_1.2.6.zip'
Content type 'application/zip' length 90420 bytes (88 KB)
downloaded 88 KB

trying URL 'https://cran.rstudio.com/bin/windows/contrib/3.5/maps_3.3.0.zip'
Content type 'application/zip' length 3694151 bytes (3.5 MB)
downloaded 3.5 MB

trying URL 'https://cran.rstudio.com/bin/windows/contrib/3.5/maptools_0.9-4.zip'
Content type 'application/zip' length 2143234 bytes (2.0 MB)
downloaded 2.0 MB

trying URL 'https://cran.rstudio.com/bin/windows/contrib/3.5/multcomp_1.4-8.zip'
Content type 'application/zip' length 733097 bytes (715 KB)
downloaded 715 KB

trying URL 'https://cran.rstudio.com/bin/windows/contrib/3.5/munsell_0.5.0.zip'
Content type 'application/zip' length 243832 bytes (238 KB)
downloaded 238 KB

trying URL 'https://cran.rstudio.com/bin/windows/contrib/3.5/testthat_2.0.0.zip'
Content type 'application/zip' length 1692064 bytes (1.6 MB)
downloaded 1.6 MB

trying URL 'https://cran.rstudio.com/bin/windows/contrib/3.5/vdiffr_0.2.3.zip'
Content type 'application/zip' length 714341 bytes (697 KB)
downloaded 697 KB

trying URL 'https://cran.rstudio.com/bin/windows/contrib/3.5/quantreg_5.36.zip'
Content type 'application/zip' length 2376647 bytes (2.3 MB)
downloaded 2.3 MB

trying URL 'https://cran.rstudio.com/bin/windows/contrib/3.5/rgeos_0.3-28.zip'
Content type 'application/zip' length 1895085 bytes (1.8 MB)
downloaded 1.8 MB

trying URL 'https://cran.rstudio.com/bin/windows/contrib/3.5/sf_0.6-3.zip'
Content type 'application/zip' length 39654854 bytes (37.8 MB)
downloaded 37.8 MB

trying URL 'https://cran.rstudio.com/bin/windows/contrib/3.5/svglite_1.2.1.zip'
Content type 'application/zip' length 653469 bytes (638 KB)
downloaded 638 KB

trying URL 'https://cran.rstudio.com/bin/windows/contrib/3.5/ggplot2_3.0.0.zip'
Content type 'application/zip' length 3579962 bytes (3.4 MB)
downloaded 3.4 MB

package 'fansi' successfully unpacked and MD5 sums checked
package 'utf8' successfully unpacked and MD5 sums checked
package 'curl' successfully unpacked and MD5 sums checked
package 'openssl' successfully unpacked and MD5 sums checked
package 'bindr' successfully unpacked and MD5 sums checked
package 'checkmate' successfully unpacked and MD5 sums checked
package 'rstudioapi' successfully unpacked and MD5 sums checked
package 'zoo' successfully unpacked and MD5 sums checked
package 'memoise' successfully unpacked and MD5 sums checked
package 'whisker' successfully unpacked and MD5 sums checked
package 'git2r' successfully unpacked and MD5 sums checked
package 'fontBitstreamVera' successfully unpacked and MD5 sums checked
package 'fontLiberation' successfully unpacked and MD5 sums checked
package 'httpuv' successfully unpacked and MD5 sums checked
package 'xtable' successfully unpacked and MD5 sums checked
package 'sourcetools' successfully unpacked and MD5 sums checked
package 'later' successfully unpacked and MD5 sums checked
package 'promises' successfully unpacked and MD5 sums checked
package 'spData' successfully unpacked and MD5 sums checked
package 'e1071' successfully unpacked and MD5 sums checked
package 'labeling' successfully unpacked and MD5 sums checked
package 'R6' successfully unpacked and MD5 sums checked
package 'RColorBrewer' successfully unpacked and MD5 sums checked
package 'cli' successfully unpacked and MD5 sums checked
package 'crayon' successfully unpacked and MD5 sums checked
package 'pillar' successfully unpacked and MD5 sums checked
package 'rex' successfully unpacked and MD5 sums checked
package 'httr' successfully unpacked and MD5 sums checked
package 'assertthat' successfully unpacked and MD5 sums checked
package 'bindrcpp' successfully unpacked and MD5 sums checked
package 'pkgconfig' successfully unpacked and MD5 sums checked
package 'tidyselect' successfully unpacked and MD5 sums checked
package 'BH' successfully unpacked and MD5 sums checked
package 'plogr' successfully unpacked and MD5 sums checked
package 'Formula' successfully unpacked and MD5 sums checked
package 'latticeExtra' successfully unpacked and MD5 sums checked
package 'acepack' successfully unpacked and MD5 sums checked
package 'gridExtra' successfully unpacked and MD5 sums checked
package 'data.table' successfully unpacked and MD5 sums checked
package 'htmlTable' successfully unpacked and MD5 sums checked
package 'viridis' successfully unpacked and MD5 sums checked
package 'sp' successfully unpacked and MD5 sums checked
package 'mvtnorm' successfully unpacked and MD5 sums checked
package 'TH.data' successfully unpacked and MD5 sums checked
package 'sandwich' successfully unpacked and MD5 sums checked
package 'colorspace' successfully unpacked and MD5 sums checked
package 'praise' successfully unpacked and MD5 sums checked
package 'devtools' successfully unpacked and MD5 sums checked
package 'fontquiver' successfully unpacked and MD5 sums checked
package 'gdtools' successfully unpacked and MD5 sums checked
package 'htmlwidgets' successfully unpacked and MD5 sums checked
package 'purrr' successfully unpacked and MD5 sums checked
package 'shiny' successfully unpacked and MD5 sums checked
package 'xml2' successfully unpacked and MD5 sums checked
package 'SparseM' successfully unpacked and MD5 sums checked
package 'MatrixModels' successfully unpacked and MD5 sums checked
package 'DBI' successfully unpacked and MD5 sums checked
package 'units' successfully unpacked and MD5 sums checked
package 'classInt' successfully unpacked and MD5 sums checked
package 'gtable' successfully unpacked and MD5 sums checked
package 'lazyeval' successfully unpacked and MD5 sums checked
package 'plyr' successfully unpacked and MD5 sums checked
package 'reshape2' successfully unpacked and MD5 sums checked
package 'rlang' successfully unpacked and MD5 sums checked
package 'scales' successfully unpacked and MD5 sums checked
package 'tibble' successfully unpacked and MD5 sums checked
package 'viridisLite' successfully unpacked and MD5 sums checked
package 'withr' successfully unpacked and MD5 sums checked
package 'covr' successfully unpacked and MD5 sums checked
package 'dplyr' successfully unpacked and MD5 sums checked
package 'ggplot2movies' successfully unpacked and MD5 sums checked
package 'hexbin' successfully unpacked and MD5 sums checked
package 'Hmisc' successfully unpacked and MD5 sums checked
package 'mapproj' successfully unpacked and MD5 sums checked
package 'maps' successfully unpacked and MD5 sums checked
package 'maptools' successfully unpacked and MD5 sums checked
package 'multcomp' successfully unpacked and MD5 sums checked
package 'munsell' successfully unpacked and MD5 sums checked
package 'testthat' successfully unpacked and MD5 sums checked
package 'vdiffr' successfully unpacked and MD5 sums checked
package 'quantreg' successfully unpacked and MD5 sums checked
package 'rgeos' successfully unpacked and MD5 sums checked
package 'sf' successfully unpacked and MD5 sums checked
package 'svglite' successfully unpacked and MD5 sums checked
package 'ggplot2' successfully unpacked and MD5 sums checked

The downloaded binary packages are in
C:\Users\lucas\AppData\Local\Temp\RtmpiWdPU6\downloaded_packages
> install.packages('data.table', dependencies = TRUE)
Installing package into 'C:/Users/lucas/Documents/R/win-library/3.5'
(as 'lib' is unspecified)
also installing the dependencies 'bit', 'R.oo', 'R.methodsS3', 'RcppCCTZ', 'bit64', 'R.utils', 'xts', 'nanotime'


There is a binary version available but the source version is later:
  binary source needs_compilation
RcppCCTZ  0.2.3  0.2.4              TRUE

Binaries will be installed
trying URL 'https://cran.rstudio.com/bin/windows/contrib/3.5/bit_1.1-14.zip'
Content type 'application/zip' length 245993 bytes (240 KB)
downloaded 240 KB

trying URL 'https://cran.rstudio.com/bin/windows/contrib/3.5/R.oo_1.22.0.zip'
Content type 'application/zip' length 955856 bytes (933 KB)
downloaded 933 KB

trying URL 'https://cran.rstudio.com/bin/windows/contrib/3.5/R.methodsS3_1.7.1.zip'
Content type 'application/zip' length 76434 bytes (74 KB)
downloaded 74 KB

trying URL 'https://cran.rstudio.com/bin/windows/contrib/3.5/RcppCCTZ_0.2.3.zip'
Content type 'application/zip' length 737639 bytes (720 KB)
downloaded 720 KB

trying URL 'https://cran.rstudio.com/bin/windows/contrib/3.5/bit64_0.9-7.zip'
Content type 'application/zip' length 547131 bytes (534 KB)
downloaded 534 KB

trying URL 'https://cran.rstudio.com/bin/windows/contrib/3.5/R.utils_2.7.0.zip'
Content type 'application/zip' length 1378006 bytes (1.3 MB)
downloaded 1.3 MB

trying URL 'https://cran.rstudio.com/bin/windows/contrib/3.5/xts_0.11-1.zip'
Content type 'application/zip' length 953758 bytes (931 KB)
downloaded 931 KB

trying URL 'https://cran.rstudio.com/bin/windows/contrib/3.5/nanotime_0.2.3.zip'
Content type 'application/zip' length 115007 bytes (112 KB)
downloaded 112 KB

trying URL 'https://cran.rstudio.com/bin/windows/contrib/3.5/data.table_1.11.8.zip'
Content type 'application/zip' length 1831980 bytes (1.7 MB)
downloaded 1.7 MB

package 'bit' successfully unpacked and MD5 sums checked
package 'R.oo' successfully unpacked and MD5 sums checked
package 'R.methodsS3' successfully unpacked and MD5 sums checked
package 'RcppCCTZ' successfully unpacked and MD5 sums checked
package 'bit64' successfully unpacked and MD5 sums checked
package 'R.utils' successfully unpacked and MD5 sums checked
package 'xts' successfully unpacked and MD5 sums checked
package 'nanotime' successfully unpacked and MD5 sums checked
package 'data.table' successfully unpacked and MD5 sums checked

The downloaded binary packages are in
C:\Users\lucas\AppData\Local\Temp\RtmpiWdPU6\downloaded_packages
> library(Hmisc)
Carregando pacotes exigidos: lattice
Carregando pacotes exigidos: survival
Carregando pacotes exigidos: Formula
Carregando pacotes exigidos: ggplot2

Attaching package: 'Hmisc'

The following objects are masked from 'package:base':
  
  format.pval, units

> install.packages("readxl")
Installing package into 'C:/Users/lucas/Documents/R/win-library/3.5'
(as 'lib' is unspecified)
also installing the dependencies 'rematch', 'cellranger'

trying URL 'https://cran.rstudio.com/bin/windows/contrib/3.5/rematch_1.0.1.zip'
Content type 'application/zip' length 15997 bytes (15 KB)
downloaded 15 KB

trying URL 'https://cran.rstudio.com/bin/windows/contrib/3.5/cellranger_1.1.0.zip'
Content type 'application/zip' length 103270 bytes (100 KB)
downloaded 100 KB

trying URL 'https://cran.rstudio.com/bin/windows/contrib/3.5/readxl_1.1.0.zip'
Content type 'application/zip' length 1499854 bytes (1.4 MB)
downloaded 1.4 MB

package 'rematch' successfully unpacked and MD5 sums checked
package 'cellranger' successfully unpacked and MD5 sums checked
package 'readxl' successfully unpacked and MD5 sums checked

The downloaded binary packages are in
C:\Users\lucas\AppData\Local\Temp\RtmpiWdPU6\downloaded_packages
> library(Hmisc)
> install.packages("forecast")
Installing package into 'C:/Users/lucas/Documents/R/win-library/3.5'
(as 'lib' is unspecified)
also installing the dependencies 'TTR', 'quadprog', 'quantmod', 'fracdiff', 'lmtest', 'timeDate', 'tseries', 'urca', 'uroot', 'RcppArmadillo'

trying URL 'https://cran.rstudio.com/bin/windows/contrib/3.5/TTR_0.23-4.zip'
Content type 'application/zip' length 522789 bytes (510 KB)
downloaded 510 KB

trying URL 'https://cran.rstudio.com/bin/windows/contrib/3.5/quadprog_1.5-5.zip'
Content type 'application/zip' length 301971 bytes (294 KB)
downloaded 294 KB

trying URL 'https://cran.rstudio.com/bin/windows/contrib/3.5/quantmod_0.4-13.zip'
Content type 'application/zip' length 942898 bytes (920 KB)
downloaded 920 KB

trying URL 'https://cran.rstudio.com/bin/windows/contrib/3.5/fracdiff_1.4-2.zip'
Content type 'application/zip' length 128679 bytes (125 KB)
downloaded 125 KB

trying URL 'https://cran.rstudio.com/bin/windows/contrib/3.5/lmtest_0.9-36.zip'
Content type 'application/zip' length 359145 bytes (350 KB)
downloaded 350 KB

trying URL 'https://cran.rstudio.com/bin/windows/contrib/3.5/timeDate_3043.102.zip'
Content type 'application/zip' length 1542922 bytes (1.5 MB)
downloaded 1.5 MB

trying URL 'https://cran.rstudio.com/bin/windows/contrib/3.5/tseries_0.10-45.zip'
Content type 'application/zip' length 415337 bytes (405 KB)
downloaded 405 KB

trying URL 'https://cran.rstudio.com/bin/windows/contrib/3.5/urca_1.3-0.zip'
Content type 'application/zip' length 1060714 bytes (1.0 MB)
downloaded 1.0 MB

trying URL 'https://cran.rstudio.com/bin/windows/contrib/3.5/uroot_2.0-9.zip'
Content type 'application/zip' length 1913338 bytes (1.8 MB)
downloaded 1.8 MB

trying URL 'https://cran.rstudio.com/bin/windows/contrib/3.5/RcppArmadillo_0.9.100.5.0.zip'
Content type 'application/zip' length 2268480 bytes (2.2 MB)
downloaded 2.2 MB

trying URL 'https://cran.rstudio.com/bin/windows/contrib/3.5/forecast_8.4.zip'
Content type 'application/zip' length 1997966 bytes (1.9 MB)
downloaded 1.9 MB

package 'TTR' successfully unpacked and MD5 sums checked
package 'quadprog' successfully unpacked and MD5 sums checked
package 'quantmod' successfully unpacked and MD5 sums checked
package 'fracdiff' successfully unpacked and MD5 sums checked
package 'lmtest' successfully unpacked and MD5 sums checked
package 'timeDate' successfully unpacked and MD5 sums checked
package 'tseries' successfully unpacked and MD5 sums checked
package 'urca' successfully unpacked and MD5 sums checked
package 'uroot' successfully unpacked and MD5 sums checked
package 'RcppArmadillo' successfully unpacked and MD5 sums checked
package 'forecast' successfully unpacked and MD5 sums checked

The downloaded binary packages are in
C:\Users\lucas\AppData\Local\Temp\RtmpiWdPU6\downloaded_packages
> library(forecast)
> library(readxl)
> IPCA.df<-read_excel("c:/Econometria/IPCA.xls")
> plot(IPCA.df$IPCA, type = "l")
> MM <- data.frame(na.omit(ma(IPCA.df$IPCA,order = 12, centre = T)))
> View(IPCA.df)
> View(MM)
> a <- (127-nrow(MM))+1
> IPCA.DF <- as.data.frame(IPCA.df$IPCA[a:127])
> Tabela1 <- cbind(IPCA.DF,MM)
> colnames(Tabela1) <- c("IPCA","M�dia m�vel")
> View(Tabela1)
> Grafico <- ts(Tabela1, start = 2008, frequency = 12)
> plot(Grafico, plot.type = "single", col=c("Black","Blue"))
> z <- lm(IPCA.df$IPCA~IPCA.df$Ano.M�s)
> abline(z, col="Green")
> summary(z)

Call:
  lm(formula = IPCA.df$IPCA ~ IPCA.df$Ano.M�s)

Residuals:
  Min       1Q   Median       3Q      Max 
-0.82458 -0.22349 -0.08363  0.20146  1.19230 

Coefficients:
  Estimate Std. Error t value Pr(>|t|)
(Intercept)      7.388e-01  4.464e-01   1.655    0.100
IPCA.df$Ano.M�s -2.180e-10  3.262e-10  -0.668    0.505

Residual standard error: 0.3545 on 125 degrees of freedom
Multiple R-squared:  0.00356,	Adjusted R-squared:  -0.004412 
F-statistic: 0.4466 on 1 and 125 DF,  p-value: 0.5052

> tabela2 <- as.data.frame(Tabela1$IPCA/Tabela1$`M�dia m�vel`)
> plot(tabela2)
> Inflacao <- ts(IPCA.df$IPCA, start = 2008, frequency = 12)
> decomposicao <- decompose(Inflacao)
> plot(decompose(Inflacao))
> Tendencia <- decomposicao$trend
> Sazonalidade <- decomposicao$seasonal
> Ciclo <- decomposicao$random
> Tab_Dados1 <- data.frame(IPCA.df$IPCA, Ciclo)
> View(Tab_Dados1)
> plot(Sazonalidade, type="l")
> Serie_Tempo1 <- ts(Tab_Dados1, start = 2008, frequency = 12)
> plot(Serie_Tempo1, plot.type = "single", col= c("Blue", "Red"))
> Tab_Dados2 <- data.frame(IPCA.df$IPCA, Tendencia)
> Serie_Tempo2 <- ts(Tab_Dados2, start = 2008, frequency = 12)
> plot(Serie_Tempo2, plot.type = "single", col= c("Blue", "Red"))