# Aula-16
Econometria Avançada - Aula 16
