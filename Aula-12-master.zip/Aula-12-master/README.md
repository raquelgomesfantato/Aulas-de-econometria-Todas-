# Aula-12
Econometria Avançada - Aula 12
